<?php
	session_start();

	$dbUser = 'root';
	$dbPass = '';

	try{
		$bdd = new PDO ('mysql:host = localhost;port=3307;dbname=videogames', $dbUser, $dbPass); 
	}catch(PDOException $e){
		echo'Base de donnée indisponible.';
	}

// 	$message = '';

//   $pdoStat = $bdd->prepare('INSERT INTO videogames VALUES (NULL, :Title, :ReleaseDate)');

// // $pdoStat->bindValue(':Title', $_POST['titre'], PDO::PARAM_STR);
// // $pdoStat->bindValue(':ReleaseDate', $_POST['sortie'], PDO::PARAM_STR);


// $insertIsOk = $pdoStat->execute();

// if($insertIsOk){
// 	$message = 'Le jeu a été ajouté';
// }else{
// 	$message = 'echec dajout du jeu';
// }


	

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php if(!empty($message)): ?>
        <div class="alert">
          <?= $message; ?>
        </div>
      <?php endif; ?>
</body>
</html>
