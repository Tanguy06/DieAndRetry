<?php
session_start();

	$dbUser = 'root';
	$dbPass = '';

	try{
		$bdd = new PDO ('mysql:host = localhost;port=3307;dbname=videogames', $dbUser, $dbPass); 
	}catch(PDOException $e){
		echo'Base de donnée indisponible.';
	}

$id = $_GET['id'];  
$sql = 'DELETE FROM videogames WHERE id=:id';
$statement = $bdd->prepare($sql);
if ($statement->execute([':id' => $id])) {
  header("Location: main.php?id=".$_SESSION['id']);
}else{
	echo '<div class="alert">Erreur lors de la suppression</div>';
}