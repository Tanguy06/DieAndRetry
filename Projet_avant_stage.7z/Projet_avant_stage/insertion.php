<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style3.css">
	<link href="https://fonts.googleapis.com/css?family=Bungee" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/js/bootstrap.min.js"></script>
</head>
<body>

  
	<header class="text-center">
		<a href="main.php"><img src="DieAndRetry2.png"></a>	
	</header>
	<div class="Titre text-center mb-3 mt-5">
		<h2>Ajouter un jeu</h2>
	</div>
	


	<form class="centre pt-3" action="ajt.php" method="post">
  		<div class="form-group ">
    		<label for="Title">Nom<p class="red pl-2">Obligatoire</p></label>
    		
    		<input type="text"  class="form-control" name="titre" id="Title" aria-describedby="text" placeholder="Nom du jeu">
  		</div>

  		<div class="form-group ">
    		<label for="ReleaseDate">Date de sortie <p class="red pl-2">Obligatoire</p></label>
    		
    		<input type="date"  class="form-control" name="sortie" id="ReleaseDate" aria-describedby="text">
  		</div>

  		<div class="form-group pt-2 pb-3">
    		<label for="genre">Genre<p class="red pl-2">Obligatoire</p></label>
    		
    		<input type="text"  class="form-control" name ="genre" id="genre" placeholder="FPS, action, rpg...">
  		</div>

  		<div class="form-group ">
    		<label for="constructeur">Constructeur<p class="red pl-2">Obligatoire</p></label>
    		
    		<input type="text"  class="form-control" name = "constructeur" id="constructeur" aria-describedby="text" placeholder="Constructeur du jeu">
  		</div>

  		<div class="form-group ">
    		<label for="developper">Developper<p class="red pl-2">Obligatoire</p></label>
    		
    		<input type="text"  class="form-control" name ="developper" id="developper" aria-describedby="text" placeholder="developper(s) du jeu">
  		</div>

  		<div class="form-group ">
    		<label for="plateforme">Plateforme<p class="red pl-2">Obligatoire</p></label>
    		
    		<input type="text"  class="form-control" name = "plateforme" id="plateforme" aria-describedby="text" placeholder="PS4, wii, NES, Super NES...">
  		</div>

  		<div class="form-group pb-3 ">
    		<label for="editeur">Editeur<p class="red pl-2">Obligatoire</p></label>
    		
    		<input type="text"  class="form-control" name = "editeur" id="editeur" aria-describedby="text" placeholder="editeur(s) du jeu">
  		</div>

  		<input type="submit" value="Ajouter" name="formconnexion" class=" col-md-12 col-lg-push-12 btn outline p-2">
	</form>
	<footer class=" mentions-legales">
		<p class="text-center black"> <a href ="#" >Politique de confidentialité </a> • <a href="#"> FAQ </a> • <a href="#"> Nous contacter </a></p>
	</footer>

	

</body>
</html>