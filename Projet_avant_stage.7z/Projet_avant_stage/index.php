<?php
	session_start();

	$dbUser = 'root';
	$dbPass = '';

	try{
		$bdd = new PDO ('mysql:host = localhost;port=3307;dbname=videogames', $dbUser, $dbPass); 
	}catch(PDOException $e){
		echo'Base de donnée indisponible.';
	}

	if(isset($_POST['formconnexion'])) {
   $login = htmlspecialchars($_POST['login']);
   $mdp = sha1($_POST['mdp']);
   if(!empty($login) AND !empty($mdp)) {
      $requser = $bdd->prepare("SELECT * FROM login WHERE user = ? AND password = ?");
      $requser->execute(array($login, $mdp));
      $userexist = $requser->rowCount();
      if($userexist == 1) {
         $userinfo = $requser->fetch();
         $_SESSION['id'] = $userinfo['id'];
         $_SESSION['user'] = $userinfo['user'];
         $_SESSION['password'] = $userinfo['password'];
         header("Location: main.php?id=".$_SESSION['id']);
      } else {
         $erreur = "Nom d'utilisateur ou mot de passe incorrect...";
      }
   } else {
      $erreur = "Tous les champs doivent être complétés !";
   }
}



	?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css?family=Bungee" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/js/bootstrap.min.js"></script>
</head>
<body>
	<!-- logo -->
	<div class="text-center LeTop">
		<img class="logo" src="DieAndRetry2.png">
	</div>
	<!-- Titre "Se connecter" -->
	<div class="Titre text-center text-white LeTop2 mb-3">
		<h2>Se connecter</h2>
	</div>
	<!-- formulaire de connexion (bootstrap) -->
	<form class="centre " action="" method="post">
  		<div class="form-group ">
    		<label for="login">Pseudo<p class="red pl-3">Obligatoire</p></label>
    		
    		<input type="text"  class="form-control" name = "login" id="login" aria-describedby="text" placeholder="Entrer votre nom d'utilisateur">
  		</div>

  		<div class="form-group pt-2 pb-3">
    		<label for="password">Mot de passe<p class="red pl-3">Obligatoire</p></label>
    		
    		<input type="password"  class="form-control" name ="mdp" id="password" placeholder="*******">
  		</div>

  		<input type="submit" value="Connexion" name="formconnexion" class=" col-md-12 col-lg-push-12 btn outline p-2">
	</form>
	
         <?php
         if(isset($erreur)) {
         	
            echo '<div class="error text-center mt-5">'.$erreur."</div>";
         }
         ?>

    <footer class=" mentions-legales">
		<p class="text-center"> <a href ="#" >Politique de confidentialité </a> • <a href="#"> FAQ </a> • <a href="#"> Nous contacter </a></p>
	</footer>
</body>
</html>