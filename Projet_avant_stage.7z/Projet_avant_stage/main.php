<?php
	session_start();

	$dbUser = 'root';
	$dbPass = '';

	try{
		$bdd = new PDO ('mysql:host = localhost;port=3307;dbname=videogames', $dbUser, $dbPass); 
	}catch(PDOException $e){
		echo'Base de donnée indisponible.';
	}

	$pdostat = $bdd->prepare('
		SELECT videogames.Title AS nom_jeu, videogames.id AS id, videogames.ReleaseDate AS date_sortie,platform.name AS nom_plateform,publishers.name AS nom_publisher, developers.name AS nom_devs
		FROM  videogames, platform, publishers, developers
		WHERE videogames.idPLatform = platform.id AND videogames.idPublisher = publishers.id AND videogames.idDeveloper = developers.id'); 

	$executeIsOk = $pdostat->execute();  
	$Jeu = $pdostat->fetchAll(); 


	if(isset($_POST['find'])){

		$Title  = $_POST['Title'];

		
		$pdoResult = $bdd->prepare($pdostat);
		$pdoExec = $pdoResult->execute(array(':Title'=>$Title));

		if ($pdoExec) {
		echo "<td>".$Jeu['nom_jeu']."</td>";
		echo "<td class='none'>".$Jeu['date_sortie']."</td>";
		echo "<td class='none'>".$Jeu['nom_plateform']."</td>";
		echo "<td class='none'>".$Jeu['nom_publisher']."</td>";
		echo '<td class="none">'.$Jeu['nom_devs'].'</td>';
		echo '<td>'?>
		<a onclick="return confirm('Êtes-vous sur de vouloir supprimer ce jeu ?')" href="delete.php?id=<?= $Jeu['id'] ?>" class='btn btn-danger'>Supprimer</a>
		<?php
			
		}else{
			echo 'ERROR2';
		}
	}
	


?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<link href="https://fonts.googleapis.com/css?family=Bungee" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/js/bootstrap.min.js"></script>
</head>
<body>
	<header>
		<a class="logo" href="main.php"><img src="DieAndRetry2.png"></a>
		<div class="ajt"><a class="ajtt" href="insertion.php">
			<i class="fas fa-plus fa-2x plus"></i>
			<label>Ajouter un jeu</label></a>
		</div>	
		<form class="form-inline">
      		<input class="form-control search col-11 " type="text" name="find" placeholder="Rechercher un jeu..." aria-label="Search">
      		<!-- <input type="submit" name ="find" value="Rechercher>" -->
    	</form>
	</header>
	<div class="text-center text-white col-11 mt-4 div1"><label>Tout les jeux</label></div>

	
	<table class="table table-fixed table-bordered align mt-4 col-11">
	<thead class="thead-dark ">
	 <tr>
		<th scope="col-2" ><p >Nom</p></th>
		<th scope="col-2" class="none"><p >Date de Sortie</p></th>
		<th scope="col-2" class="none"><p >Plateforme</p></th>
		<th scope="col-2" class="none"><p >Editeurs</p></th>
		<th scope="col-2" class="none"><p >Developpers</p></th>
	</tr>
	</thead>
	<tbody>
	<tr>
<?php

	foreach ($Jeu as $Jeu) {
		?>
		<tr>
		<?php	
		echo "<td>".$Jeu['nom_jeu']."</td>";
		echo "<td class='none'>".$Jeu['date_sortie']."</td>";
		echo "<td class='none'>".$Jeu['nom_plateform']."</td>";
		echo "<td class='none'>".$Jeu['nom_publisher']."</td>";
		echo '<td class="none">'.$Jeu['nom_devs'].'</td>';
		echo '<td>'?><a onclick="return confirm('Êtes-vous sur de vouloir supprimer ce jeu ?')" href="delete.php?id=<?= $Jeu['id'] ?>" class='btn btn-danger'>Supprimer</a>
		<?php
	

		
		echo "</tr>";
	}
?>

	</tr>
	</tbody>
	</table>
	
	<footer class=" mentions-legales">
		<p class="text-center"> <a href ="#" >Politique de confidentialité </a> • <a href="#"> FAQ </a> • <a href="#"> Nous contacter </a></p>
	</footer>

</body>
</html>